export { InsideProduct } from "./InsideProduct";
